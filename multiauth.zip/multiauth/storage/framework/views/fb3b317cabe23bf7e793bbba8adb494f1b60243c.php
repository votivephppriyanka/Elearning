<?php $__env->startSection('title', 'Change Password'); ?>

<?php $__env->startSection('current_page_css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('current_page_js'); ?>
<script type="text/javascript">
  $('#studentForm').validate({ 
      // initialize the plugin
      rules: {
       first_name: {
        required: true
      },

      last_name: {
        required: true
      },

      contact_number: {
        required: true
      },

      email: {
        required: true
      },

      password: {
        required: true
      }
    },
    submitHandler: function(form) {
      form.submit();
    }
  });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Tutors
        <small>Change Password</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Change Password</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <?php if($message = Session::get('message')): ?>
       <div class="alert alert-success alert-block">  
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <strong><?php echo e($message); ?></strong>
      </div>
      <?php endif; ?>

      <?php if($message = Session::get('error')): ?>
      <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <strong><?php echo e($message); ?></strong>
      </div>
      <?php endif; ?>

      <?php if($message = Session::get('warning')): ?>
      <div class="alert alert-warning alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <strong><?php echo e($message); ?></strong>
      </div>
      <?php endif; ?>

      <?php if($message = Session::get('info')): ?>
      <div class="alert alert-info alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <strong><?php echo e($message); ?></strong>
      </div>
      <?php endif; ?>

      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </ul>
     </div>
     <?php endif; ?>
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-xs-12">
          <!-- SELECT2 EXAMPLE -->
        <div class="box box-default">
          <div class="box-header with-border">
            <h3 class="box-title">Change Password</h3>
            <div class="box-tools pull-right">
              <!--<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>-->
            </div>
          </div>
          <!-- /.box-header -->
          <form action="<?php echo e(url('/admin/update_tutor_password')); ?>" id="changePasswordForm" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
            <input type="hidden" name="tutor_id" value="<?php echo e((!empty($tutor_info->id) ? $tutor_info->id : '')); ?>" />
            <div class="box-body">
              <div class="row">
                <div class="col-md-6">

                  <div class="form-group<?php echo e($errors->has('new-password') ? ' has-error' : ''); ?>">
                  <label for="new-password">New Password</label>
                  <input type="password" class="form-control" name="new-password" id="new-password" placeholder="New Password">
                  <?php if($errors->has('new-password')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('new-password')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div>

                <div class="form-group">
                  <label for="new-password-confirm">New Confirm Password</label>
                  <input type="password" class="form-control" name="new-password_confirmation" id="new-password-confirm" placeholder="New Confirm Password">
                </div>
                  <!-- /.form-group -->

                </div>
                <!-- /.col -->
              </div>
            </div>
            <div class="box-footer">
              <button type="submit" class="btn btn-primary">Update Password</button>
            </div>
            <!-- /.row -->
          </form>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\multiauth\resources\views/admin/tutor/change_password.blade.php ENDPATH**/ ?>