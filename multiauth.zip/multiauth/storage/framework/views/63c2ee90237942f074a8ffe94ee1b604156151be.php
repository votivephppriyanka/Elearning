<?php $__env->startSection('title', 'Grade List'); ?>

<?php $__env->startSection('current_page_css'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/assets/css/bootstrap-toggle.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('current_page_js'); ?>
<!-- DataTables -->
<script src="<?php echo e(url('/')); ?>/resources/assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/js/bootstrap-toggle.min.js"></script>
<script type="text/javascript">
  $(function () {
    $('#grade_list').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<script type="text/javascript">
 function delete_grade(grade_id){
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });
  $.ajax({
   type: 'POST',
   url: "<?php echo url('/admin/delete_grade'); ?>",
   enctype: 'multipart/form-data',
   data:{grade_id:grade_id,'_token':'<?php echo csrf_token(); ?>'},
     beforeSend:function(){
       return confirm("Are you sure you want to delete this item?");
     },
     success: function(resultData) { 
       console.log(resultData);
       var obj = JSON.parse(resultData);
       if (obj.status == 'success') {
          $('#success_message').fadeIn().html(obj.msg);
          setTimeout(function() {
            $('#success_message').fadeOut("slow");
          }, 2000 );
          $("#row" + grade_id).remove();
       }
     },
     error: function(errorData) {
      console.log(errorData);
      alert('Please refresh page and try again!');
    }
  });
}
</script>
<script>
  $('.toggle-class').on("change", function() {
    var status = $(this).prop('checked') == true ? 1 : 0; 
    var grade_id = $(this).data('id'); 
    
    $.ajax({
      type: "GET",
      dataType: "json",
      url: "<?php echo url('/admin/change_grade_status'); ?>",
      data: {'status': status, 'grade_id': grade_id},
      success: function(data){
        $('#success_message').fadeIn().html(data.success);
        setTimeout(function() {
          $('#success_message').fadeOut("slow");
        }, 2000 );
      },
      error: function(errorData) {
        console.log(errorData);
        alert('Please refresh page and try again!');
      }
    });
  })
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Grade
        <small>Grade List</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Grade</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <p style="display: none;" id="success_message" class="alert alert-success"></p>
      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
       <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </ul>
     </div>
     <?php endif; ?>

     <?php if(Session::has('message')): ?>
     <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('message')); ?></p>
     <?php endif; ?>

     <?php if(Session::has('error')): ?>
     <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
     <?php endif; ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title pull-left"><h3 class="box-title" >Grade List</h3>
              <h3 class="box-title pull-right"><a href="<?php echo e(url('/admin/add_grade')); ?>" class="btn btn-primary">Add</a></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="grade_list" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>S.No.</th>
                    <th>Grade Name</th>
                    <th>Status</th>
                    <th>Create Date</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(!$grade_list->isEmpty()): ?>
                  <?php $i=1; ?>
                  <?php $__currentLoopData = $grade_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr id="row<?php echo e($arr->id); ?>">
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($arr->grade); ?></td>
                    <td>
                      <input data-id="<?php echo e($arr->id); ?>" class="toggle-class" type="checkbox" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="InActive" <?php echo e($arr->status ? 'checked' : ''); ?>>
                    </td>
                    <td><?php echo e((!empty($arr->created_at) ? date('d-m-Y H:i A',strtotime($arr->created_at)) : 'N/A')); ?></td>
                    <td>

                      <a href="<?php echo e(url('/admin/edit_grade')); ?>/<?php echo e(base64_encode($arr->id)); ?>"><i class="fa fa-edit" aria-hidden="true" alt="edit" title="edit"></i></a>

                      <a href="javascript:void(0)" onclick="delete_grade('<?php echo $arr->id; ?>');"><i class="fa fa-trash" aria-hidden="true" alt="delete" title="delete"></i></a>

                    </td>
                  </tr>
                  <?php $i++; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\multiauth\resources\views/admin/grade/grade_list.blade.php ENDPATH**/ ?>