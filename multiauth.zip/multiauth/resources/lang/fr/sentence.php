<?php

// sentence.php

return [
  'welcome' => 'Bienvenue mon ami'
];