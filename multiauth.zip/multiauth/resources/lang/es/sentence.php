<?php

// sentence.php

return [
  'welcome' => 'Bienvenido amigo'
];